# Laird Co. — Main Website (Impact Dashboard)

This is the consolidated Laird Co. site. The old FAQ area was replaced by **Impact Dashboard**, the selected interactive cost/time savings calculator. The approved **Workflow Studio** section remains unchanged, as do the scrolling story section, hero with React Bits SideRays WebGL effect, lead form layout, and brand styling.

## View & deploy
Open `index.html` locally to preview. The HTML contains its CSS and JavaScript (no build step; Inter is loaded from Google Fonts when online). Deploy `index.html` to Cloudflare Pages as a static site.

## Calculator
Inputs: weekly repetitive task count, minutes per task, estimated team cost per hour, and percent of time that could be reduced. The model calculates (tasks per week × minutes per task / 60 × % reduction × hourly team cost × 48 working weeks). It provides estimated annual staff-time value, estimated hours returned, and a 12-month cumulative chart with a `$ Value` / `Hours` toggle.

The output is **value of recoverable staff capacity**, not guaranteed cash savings or ROI. It does not deduct implementation, software, or maintenance costs. Example default: 120 tasks/week × 8 minutes × 60% × $35 × 48 weeks = $16,128/year, 460.8 hours/year.

## Contact form
The form makes a POST request to `/api/contact`. That endpoint needs to be set up with a backend service (such as a Cloudflare Pages Function) before it can send real inquiries. The ZIP does not include a working email or lead-storage backend.

## Notes
On browsers without WebGL support, the SideRays hero falls back to a dark background while keeping text readable. The input calculators and interactions work without WebGL.
